def count_in_list(items, target):
    """
    Counts the number of elements in a list.
    """
    return items.count(target)
